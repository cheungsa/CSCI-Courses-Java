package cheungsa_CS201L_Assignment1;

import java.util.ArrayList;
import java.util.Comparator;
import com.google.gson.annotations.SerializedName;

public class User {
	@SerializedName("Name")
	private Name name;
	@SerializedName("Events")
	private ArrayList<Event> events;
	private String fullName;
	
	public User(Name name) {
		this.name = name;
		this.events = null;
	}
	
	public void setName() {
		fullName = name.getFLName();
	}
	
	public String getStrName() {
		return fullName;
	}
	
	public Name getName() {
		return name;
	}
	
	public int getNumEvents() {
		if (events == null) {
			System.out.println("Uninitialized array of events");
			return -1;
		}
		return events.size();
	}
	
	public void printEvents() {
		if (events == null) {
			return;
		}
		System.out.print("\n");
		for (int i=0; i<events.size(); ++i) {
			System.out.println("\t" + Integer.toString(i+1) + ") " + events.get(i).getStrEvent());
		}
	}
	
	public ArrayList<Event> getEvents() {
		return events;
	}

	public void setEvent(Event event) {
		if (events == null) {
			ArrayList<Event> arrEvt = new ArrayList<Event>();
			arrEvt.add(event);
			events = arrEvt;
			return;
		}
		events.add(event);
	}
	
	public void sortEvents() {
		events.sort(new Comparators.DateComparator());
	}
	
	public static class Comparators {		
		static class DateComparator implements Comparator<Event>{
			@Override
			public int compare(Event e1, Event e2) {
				if (e1.getDate().getYear().compareTo(e2.getDate().getYear()) == 0) {
					String e1_month = e1.getDate().getMonth();
					String e2_month = e2.getDate().getMonth();
					if (e1.getDate().getIntMonth(e1_month).compareTo(e2.getDate().getIntMonth(e2_month)) == 0) {
						if (e1.getDate().getDay().compareTo(e2.getDate().getDay()) == 0) {
							System.out.println("/nSorting events according to time");
							if (e1.getTime().contains("am") && e2.getTime().contains("pm")) {
								return 1;
							}
							if (e2.getTime().contains("am") && e1.getTime().contains("pm")) {
								return 1;
							}
							return e1.getTime().compareTo(e2.getTime());
						}
						System.out.println("/nSorting events according to day");
						return e1.getDate().getDay().compareTo(e2.getDate().getDay());
					}
					System.out.println("/nSorting events according to month");
					return e1.getDate().getIntMonth(e1_month).compareTo(e2.getDate().getIntMonth(e1_month));
				}
				System.out.println("/nSorting events according to year");
				return e1.getDate().getYear().compareTo(e2.getDate().getYear());
			}
		}
	}
}
