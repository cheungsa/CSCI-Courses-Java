package cheungsa_CS201L_Assignment1;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

import com.google.gson.Gson;
import com.google.gson.JsonParseException;

public class Parser {
	public String filename;
	public Calendar cal;
	
	public void readFile() {
		Scanner scan = new Scanner(System.in);
		String contents = "";
		
		// ask for valid input file
		while (true) {
			try {
				System.out.print("What is the name of the input file? ");
				filename = scan.nextLine();
				FileReader fr = new FileReader(filename);
				BufferedReader br = new BufferedReader(fr);
				Gson gson = new Gson();
				cal = gson.fromJson(br, Calendar.class);
/*				
 * 				String line = br.readLine();
				while (line != null) {
					contents += line;
					line = br.readLine();
				}
				if (contents.isEmpty()) {
					System.out.println("The file is empty.");
					continue;
				}
*/
				br.close();
				fr.close();
				break;
			} catch (FileNotFoundException fnfe) {
				System.out.println("That file could not be found.");
			} catch (IOException ioe) {
				System.out.println("That file is not a well-formed JSON file.");
			} catch (JsonParseException e) {
				System.out.println("That file is not a well-formed JSON file.");
				continue;	
			} 
		}
		//scan.close();
		// initialize Gson parser to parse file contents for Calendar object
		System.out.println("Parser: contents -- " + contents);
		
/*		Gson gson = new Gson();
		cal = null;
		try {
			cal = gson.fromJson(contents, Calendar.class);
		} catch (JsonSyntaxException jse) {
			System.out.println("jse: " + jse.getMessage());
		}*/
		
		if (cal == null) {
			System.out.println("Parser: null calendar");
			return;
		}
		if (cal.getNumUsers() == -1) {
			System.out.println("Parser: uninitialized user arraylist");
			return;
		}
		if (cal.getNumUsers() == 0) {
			System.out.println("Parser: empty calendar");
			return;
		}
		System.out.println("Number of users is: " + cal.getNumUsers());
		// initialize user variables
		//for (int i=0; i<cal.getUsers().size(); ++i) {
		//	cal.getUsers().get(i).setName();
		//}	
	}
}
