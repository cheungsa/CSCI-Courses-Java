package cheungsa_CS201L_Assignment1;

import com.google.gson.annotations.SerializedName;

public class Event {
	@SerializedName("Title")
	private String title;
	@SerializedName("Time")
	private String time;
	@SerializedName("Date")
	private Date date;
	
	public Event(String title, String time, Date date) {
		this.title = title;
		this.time = time;
		this.date = date;
	}
	
	public String getTitle() {
		return title;
	}
	
	public String getTime() {
		return time;
	}
	
	public Date getDate() {
		return date;
	}
	
	public void printEvent() {
		System.out.print(title + ", " + time + ", " + date.getStrDate() + " to ");
	}
	
	public String getStrEvent() {
		return title + ", " + time + ", " + date.getStrDate();
	}
}
