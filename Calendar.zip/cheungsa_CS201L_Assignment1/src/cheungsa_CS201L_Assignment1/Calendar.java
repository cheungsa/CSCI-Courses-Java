package cheungsa_CS201L_Assignment1;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.InputMismatchException;
import java.util.NoSuchElementException;
import java.util.Scanner;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonIOException;
import com.google.gson.annotations.SerializedName;

public class Calendar {
	@SerializedName("Users")
	ArrayList<User> users;
	ArrayList<String> usernames;
	
	public void setUsers(ArrayList<User> users) {
		this.users = users;
	}
	
	public ArrayList<User> getUsers() {
		return users;
	}
	
	public int getNumUsers() {
		if (users == null) {
			return -1;
		}
		return users.size();
	}
	
	public void displayCalendar() {
		if (users.size() == 0) {
			System.out.println("\nCalendar is empty.");
			return;
		}
		System.out.print("\n");
		for (int i=0; i<users.size(); ++i) {
			User currUser = users.get(i);
			System.out.println("\t" + Integer.toString(i+1) + ") " + currUser.getName().getLName() + ", " + currUser.getName().getFName());
			if (users.get(i).getEvents() == null) {
				continue;
			}
			char index = 'a';
			for (int j=0; j<users.get(i).getEvents().size(); ++j)
			{
				Event event = users.get(i).getEvents().get(j);
				System.out.println("\t\t" + index + ". " + event.getTitle() + ", " + event.getTime() + ", " + event.getDate().getStrDate());
				++index;
			}
		}
	}
	
	public void displayUsers() {
		System.out.print("\n");
		for (int i=0; i<users.size(); ++i) {
			User currUser = users.get(i);
			System.out.println("\t" + Integer.toString(i+1) + ") " + currUser.getName().getLName() + ", " + currUser.getName().getFName());
		}
	}
	
	public void addUser(String fname, String lname) {
		if (usernames.contains(lname + ", " + fname)) {
			System.out.println("User already exists");
			return;
		}
		Name name = new Name(fname, lname);
		User user = new User(name);
		usernames.add(fname + " " + lname);;
		users.add(user);
	}
	
	public void removeUser(int index) {
		users.remove(index-1); // to account for index 0
	}
	
	public void addEvent(int index, Event event) {
		users.get(index).setEvent(event);
		System.out.println("Added: " + event.getTitle() + ", " + event.getTime() + ", " + 
	                       event.getDate().getStrDate() + " to " + users.get(index).getName().getFLName() +
	                       "'s calendar.");
		users.get(index).sortEvents();
	}	
	
	public void deleteEvent(int index, int eIndex) {
		System.out.println("\n" + users.get(index).getEvents().get(eIndex).getTitle() + " has been deleted.");
		users.get(index).getEvents().remove(eIndex);
	}	
	
	public void sortUsers(int input, boolean isChanged) {
		if (input == 1) {
			users.sort(new Comparators.AZComparator());
		}
		else {
			users.sort(new Comparators.ZAComparator());
		}
		isChanged = true;
		displayUsers();
	}	
	
	public void writeFile(String filename) {
		try {
			FileWriter fw = new FileWriter(filename);
			Gson gson = new GsonBuilder().create();
			gson.toJson(this, fw);
		} catch (IOException ioe) {
			System.out.println("ioe: " + ioe.getMessage());
		} catch (JsonIOException jioe) {
			System.out.println("jioe: " + jioe.getMessage());
		}
	}	
	
	public void exit(boolean isChanged, String filename) {
		if (isChanged) {
			System.out.println("\n\nChanges have been made since the file was last saved."
								+ "\n\t1) Yes"
								+ "\n\t2) No"
								+ "\nWould you like to save the file before exiting? ");
			Scanner scan = new Scanner(System.in);
			int option = -1;
			while (true) {
				try {
					option = scan.nextInt();
					scan.nextLine();
				} catch (InputMismatchException ime){
					System.out.println(ime.getMessage());
					System.out.println("\nWould you like to save the file before exiting? ");
					continue;
				} catch (NoSuchElementException nse) {
					System.out.println(nse.getMessage());
					System.out.println("\nWould you like to save the file before exiting? ");
					continue;
				}
				if (option < 1 || option > 2) {
					System.out.println("\n\nThat is not a valid option");
					System.out.println("\nWould you like to save the file before exiting? ");
					continue;
				}
				if (option == 1) {
					writeFile(filename);
				}
				break;
			}
			scan.close();
		}
		System.out.println("\n\nThank you for using my program!");
	}
	
	public String toStrMonth(String month) {
		String strMonth[] = { "January", "February", "March", "April", "May", "June",
							  "July", "August", "September", "October", "November", "December" 
							};
		return strMonth[Integer.valueOf(month)-1];
	}
	
	public static class Comparators {		
		static class AZComparator implements Comparator<User>{
			@Override
			public int compare(User u1, User u2) {
				if(u1.getName().getLName().compareTo(u2.getName().getLName()) == 0) {
					return u1.getName().getFName().compareTo(u2.getName().getFName());
				}
				return u1.getName().getLName().compareTo(u2.getName().getLName());
			}
		}
		static class ZAComparator implements Comparator<User>{
			@Override
			public int compare(User u1, User u2) {
				if(u1.getName().getLName().compareTo(u2.getName().getLName()) == 0) {
					return (-1) * u1.getName().getFName().compareTo(u2.getName().getFName());
				}else {
					return (-1) * u1.getName().getLName().compareTo(u2.getName().getLName());
				}
			}
		}
	}
}
