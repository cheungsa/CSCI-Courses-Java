package cheungsa_CS201L_Assignment1;

import java.util.Scanner;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.NoSuchElementException;
import java.io.IOException;

import com.google.gson.Gson;
import com.google.gson.JsonParseException;

public class Menu {	
	public Calendar cal;
	public String filename;
	public boolean isChanged;
	public boolean isExit;
	
	Menu() {
		cal = null;
		filename = "";
		isChanged = false;
		isExit = false;
	}
	
	public Calendar getCalendar() {
		return cal;
	}
	
	public void readFile() {
		Scanner scan = new Scanner(System.in);
		
		// ask for valid input file
		while (true) {
			try {
				System.out.print("What is the name of the input file? ");
				filename = scan.nextLine();
				FileReader fr = new FileReader(filename);
				BufferedReader br = new BufferedReader(fr);
				Gson gson = new Gson();
				cal = gson.fromJson(br, Calendar.class);
				br.close();
				fr.close();
				break;
			} catch (FileNotFoundException fnfe) {
				System.out.println("That file could not be found.");
			} catch (IOException ioe) {
				System.out.println("That file is not a well-formed JSON file.");
			} catch (JsonParseException e) {
				System.out.println("That file is not a well-formed JSON file.");
				continue;	
			} 
		}
		
		// initialize Gson parser to parse file contents for Calendar object
		if (cal == null) {
			System.out.println("Null calendar");
			return;
		}
		if (cal.getNumUsers() == -1) {
			System.out.println("Uninitialized user arraylist");
			return;
		}
		if (cal.getNumUsers() == 0) {
			System.out.println("Empty calendar");
			return;
		}
		
		// adding array list of names for sorting
		ArrayList<String> arrUsernames = new ArrayList<String>();
		for (int i=0; i<cal.getNumUsers(); ++i) {
			arrUsernames.add(cal.getUsers().get(i).getName().getLFName());
		}
		cal.usernames = arrUsernames;
	}	
	
	public void displayMenu() {
		Scanner scan = new Scanner(System.in);
		while (true) {
			System.out.print("\n\t1) Display User's Calendar" +
							 "\n\t2) Add User" +
							 "\n\t3) Remove User" +
				    		 "\n\t4) Add Event" +
							 "\n\t5) Delete Event" +
							 "\n\t6) Sort Users" +
							 "\n\t7) Write File" +
							 "\n\t8) Exit" +
						     "\n\nWhat would you like to do? "
			);
			
			// Read input
			int input = -1;
			try {
				input = scan.nextInt();
				scan.nextLine(); // to consume the \n after hitting 'Enter' key
			} catch (NumberFormatException nfe) {
				System.out.println("\nThat is not a valid option\n");
				continue;
			} catch (InputMismatchException ime) {
				System.out.println("\nThat is not a valid option\n");
				continue;
			} catch (NoSuchElementException nsee) {
				System.out.println("\nThat is not a valid option\n");
				continue;
			}
			switch (input) {
				case 1:
					cal.displayCalendar();
					break;
				case 2:
					while (true) {
						System.out.print("\n");
						System.out.print("What is the user's name? ");
						String name = scan.nextLine();
						if (!name.contains(" ")) {
							System.out.println("\nInvalid, must have first and last name.");
							continue;
						}
						try {
							String fname = name.substring(0, name.indexOf(" "));
							String lname = name.substring(name.indexOf(" ")+1);
							cal.addUser(fname, lname);	
						} catch (IndexOutOfBoundsException ioobe) {
							System.out.println(ioobe.getMessage());
							continue;					
						}
						isChanged = true;
						break;
					}
					break;
				case 3:
					if (cal.users.size() == 0) {
						System.out.println("\nThere are no users.");
						break;
					}
					cal.displayUsers();
					System.out.print("\nWhich user would you like to remove? ");
					int idx3 = -1;
					try {
						idx3 = Integer.parseInt(scan.nextLine());
					} catch (NumberFormatException nfe) {
						System.out.println("\nThat is not a valid option");
						break;
					}
					if (idx3 < 1 || idx3 > cal.users.size()) {
						System.out.println("\nThat is not a valid option");
						break;
					}
					cal.removeUser(idx3);
					isChanged = true;
					break;
				case 4:
					if (cal.users.size() == 0) {
						System.out.println("\nThere are no users.");
						break;
					}
					cal.displayUsers();
					
					// get specific user to add event to
					System.out.print("\nTo which user would you like to add an event? ");
					int idx4 = -1;
					try {
						idx4 = scan.nextInt();
						scan.nextLine();
					} catch (NumberFormatException nfe) {
						System.out.println("\nAdd user: nfe: That is not a valid option");
						break;
					} catch (InputMismatchException ime) {
						System.out.println("\nAdd user: ime: That is not a valid option");
						break;
					}
					if (idx4 < 1 || idx4 > cal.users.size()) {
						System.out.println("\nAdd user: out of bounds: That is not a valid option");
						break;
					}

					// read in event info
					System.out.print("\nWhat is the title of the event? ");
					String eTitle = "";
					try {
						eTitle = scan.nextLine();
					} catch (NoSuchElementException nsee) {
						System.out.print("nsee: " + nsee.getMessage());
						break;
					}
					if (eTitle == "") {
						System.out.print("\nInvalid title\n");
						break;
					}
					System.out.print("\nWhat time is the event? ");
					String eTime = scan.nextLine();
					if (!eTime.contains(" am") && !eTime.contains(" pm")) {
						System.out.print("\nInvalid time\n");
						break;
					}
					System.out.print("\nWhat month? ");
					int eMonth = -1;
					try {
						eMonth = scan.nextInt();
						scan.nextLine();
					} catch (InputMismatchException ime){
						System.out.println(ime.getMessage());
						break;
					} catch (NoSuchElementException nse) {
						System.out.println(nse.getMessage());
						break;
					}
					if (eMonth < 1 || eMonth > 12) {
						System.out.println("\nInvalid month\n");
						break;
					}
					System.out.print("\nWhat day? ");
					int eDay = -1;
					String eStrDay = "";
					try {
						eStrDay = scan.nextLine();
						if (eStrDay != "") {
							eDay = Integer.parseInt(eStrDay);
						}						
					} catch (NoSuchElementException nse) {
						System.out.println(nse.getMessage());
						break;
					} catch (NumberFormatException nfe) {
						System.out.println(nfe.getMessage());
						break;
					}
					if (eDay < 1 || eDay > 31) {
						System.out.println("\nInvalid day\n");
						break;
					}
					System.out.print("\nWhat year? ");
					int eYear = -1;
					String eStrYear = "";
					try {
						eStrYear = scan.nextLine();
						if (eStrYear != "") {
							eYear = Integer.parseInt(eStrYear);
						}		
					} catch (NoSuchElementException nse) {
						System.out.println(nse.getMessage());
						break;
					} catch (NumberFormatException nfe) {
						System.out.println(nfe.getMessage());
						break;
					}
					if (eYear < 2018) {
						System.out.println("\nInvalid year\n");
						break;
					}
					String strMonth = cal.toStrMonth(Integer.toString(eMonth));
					Date eDate = new Date(strMonth, eDay, eYear);
					Event uEvent = new Event(eTitle, eTime, eDate);
					cal.addEvent(idx4-1, uEvent);
					isChanged = true;
					break;
				case 5:
					if (cal.users.size() == 0) {
						System.out.println("\nThere are no users.");
						continue;
					}
					cal.displayUsers();
					
					// get specific user to add event to
					System.out.print("\nFrom which user would you like to delete an event? ");
					int idx5 = -1;
					try {
						idx5 = scan.nextInt();
						scan.nextLine();
					} catch (InputMismatchException ime) {
						System.out.println("\n" + ime.getMessage());
						break;
					} catch (NoSuchElementException nsee) {
						System.out.println("\n" + nsee.getMessage());
						break;
					}
					if (idx5 < 1 || idx5 > cal.users.size()) {
						System.out.println("\nThat is not a valid option");
						break;
					}
					
					// get specific event to remove
					if (cal.getUsers().get(idx5-1).getEvents() == null) {
						System.out.println("\nCalendar is empty.");
						break;
					}
					cal.getUsers().get(idx5-1).printEvents();
					System.out.print("\nWhich event would you like to delete? ");
					int eIdx = -1;
					try {
						eIdx = scan.nextInt();
					} catch (InputMismatchException ime) {
						System.out.println("\n" + ime.getMessage());
						break;
					} catch (NoSuchElementException nsee) {
						System.out.println("\n" + nsee.getMessage());
						break;
					}
					if (eIdx < 1 || eIdx > cal.users.get(idx5).getNumEvents()) {
						System.out.println("\nThat is not a valid option");
						break;
					}
					cal.deleteEvent(idx5-1, eIdx-1);
					break;
				case 6:
					System.out.print("\n\t1) Ascending (A-Z)"
							+ "\n\t2) Descending (Z-A)"
							+ "\n\nHow would you like to sort? ");
					int choice = -1;
					try {
						choice = scan.nextInt();
						scan.nextLine();
					} catch (InputMismatchException ime){
						System.out.println(ime.getMessage());
						break;
					} catch (NoSuchElementException nse) {
						System.out.println(nse.getMessage());
						break;
					}
					if (choice < 1 || choice > 2) {
						System.out.println("\n\nThat is not a valid option\n\n");
						break;
					}
					cal.sortUsers(choice, isChanged);
					break;
				case 7:
					cal.writeFile(filename);
					break;
				case 8:
					if (isChanged) {
						System.out.print("\nChanges have been made since the file was last saved."
											+ "\n\t1) Yes"
											+ "\n\t2) No"
											+ "\nWould you like to save the file before exiting? ");
						int option = -1;
						while (true) {
							try {
								option = scan.nextInt();
								scan.nextLine();
							} catch (InputMismatchException ime){
								System.out.println(ime.getMessage());
								System.out.print("\nWould you like to save the file before exiting? ");
								continue;
							} catch (NoSuchElementException nse) {
								System.out.println(nse.getMessage());
								System.out.print("\nWould you like to save the file before exiting? ");
								continue;
							}
							if (option < 1 || option > 2) {
								System.out.println("\n\nThat is not a valid option");
								System.out.print("\nWould you like to save the file before exiting? ");
								continue;
							}
							if (option == 1) {
								cal.writeFile(filename);
							}
							break;
						}
					}
					isChanged = false;
					isExit = true;
					break;
				default:
					System.out.println("\n\nThat is not a valid option");
					break;
			}
			if (isExit == true) {
				break;
			}
		}
	}

	public static void main(String[] args) {
		Menu menu = new Menu();
		Scanner scan = new Scanner(System.in);
		menu.readFile();		
		if (menu.getCalendar() == null) {
			System.out.println("Calendar is null");
			scan.close();
			return;
		}
		if (menu.getCalendar().getNumUsers() == 0) {
			System.out.println("Calendar is empty");
			scan.close();
			return;
		}

		while (true) {
			try {
				menu.displayMenu();
				break;
			} catch (java.lang.NullPointerException npe) {
				System.out.println("\nThat file is not a well-formed JSON file. Please try again.");
				continue;
			}
		}
		System.out.println("\nThank you for using my program!");
		scan.close();
	}
}
