package cheungsa_CS201L_Assignment1;

import com.google.gson.annotations.SerializedName;

public class Name {
	@SerializedName("Fname")
	private String fname;
	@SerializedName("Lname")
	private String lname;
	
	public Name(String fname, String lname) { 
		this.fname = fname;
		this.lname = lname;
	}
	
	public String getFLName() {
		return fname + " " + lname;
	}
	
	public String getLFName() {
		return lname + ", " + fname;
	}
	
	public String getFName() {
		return fname;
	}
	
	public String getLName() {
		return lname;
	}
}
