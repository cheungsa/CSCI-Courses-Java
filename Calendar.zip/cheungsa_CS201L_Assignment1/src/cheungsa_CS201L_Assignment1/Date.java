package cheungsa_CS201L_Assignment1;

import java.util.HashMap;
import java.util.Map;

import com.google.gson.annotations.SerializedName;

public class Date {
	@SerializedName("Month")
	private String month;
	@SerializedName("Day")
	private String day;
	@SerializedName("Year")
	private String year;
	
	public Date(String month, int day, int year) {
		this.month = month;
		this.day = Integer.toString(day);
		this.year = Integer.toString(year);
	}
	
	public String getMonth() {
		return this.month;
	}
	
	public String getDay() {
		return this.day;
	}
	
	public String getYear() {
		return this.year;
	}
	
	public String getStrDate() {
		if (day == null & year == null) return month;
		else if (year == null) return month + " " + day;
		else if (day == null) return month + ", " + year;
		return month + " " + day + ", " + year;
	}
	
	public String getStrMonth(String month) {
		String strMonth[] = { "January", "February", "March", "April", "May", "June",
							  "July", "August", "September", "October", "November", "December" 
							};
		return strMonth[Integer.valueOf(month)];
	}
	
	public String getIntMonth(String month) {
		Map<String,String> map = new HashMap<String,String>();
		map.put("January", "1");
		map.put("February", "2");
		map.put("March", "3");
		map.put("April", "4");
		map.put("May", "5");
		map.put("June", "6");
		map.put("July", "7");
		map.put("August", "8");
		map.put("September", "9");
		map.put("October", "10");
		map.put("November", "11");
		map.put("December", "12");
		return map.get(month);
	}
}
